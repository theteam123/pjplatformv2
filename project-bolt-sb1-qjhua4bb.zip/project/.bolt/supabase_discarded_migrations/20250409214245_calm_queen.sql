/*
  # Update Paul's Role

  Updates the role for paul+test@theteam.net.au to be a System Administrator in the auth.users table
  to match their Administrator profile role.
*/

-- Update Paul's role in auth.users
UPDATE auth.users 
SET role = 'authenticated'
WHERE id = '163057c9-3742-4eae-85e6-987fa152cd99';

-- Update Paul's role to be a System Administrator
UPDATE auth.users 
SET role = 'system_admin'
WHERE id = '163057c9-3742-4eae-85e6-987fa152cd99';

-- Ensure the profile is consistent
UPDATE profiles
SET role = 'System Administrator'
WHERE id = '163057c9-3742-4eae-85e6-987fa152cd99';